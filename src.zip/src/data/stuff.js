const stuff=[
  {
    "id": "newfoundlove",
    "title": "even",
    "items": [
        {
          "id": "01",
          "name": "item even 01"
        }, {
          "id": "02",
          "name": "item even 02"
        }
    ]
  },
  {
    "id": "oldfoundlove",
    "title": "odd",
    "items": [
        {
          "id": "01",
          "name": "item odd 01"
        }, {
          "id": "02",
          "name": "item odd 02"
        }
    ]
  }
];

export default stuff;
